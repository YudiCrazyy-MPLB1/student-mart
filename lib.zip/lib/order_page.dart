﻿import 'dart:async';
import 'package:flutter/material.dart';

import 'api_service.dart';
import 'utils.dart';
import 'skeleton_widgets.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({super.key});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> with WidgetsBindingObserver {
  List<Map<String, dynamic>> orders = [];

  bool isLoading = true;
  String? errorMessage;
  Timer? _autoRefreshTimer;
  bool _isFetching = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadOrders();
    _startAutoRefreshTimer();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _autoRefreshTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      // Auto refresh saat siswa membuka kembali aplikasi (mis. setelah bayar di e-wallet/bank)
      _loadOrders(silent: true);
    }
  }

  void _startAutoRefreshTimer() {
    _autoRefreshTimer?.cancel();
    _autoRefreshTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (!mounted) return;
      // Periksa apakah ada pesanan yang masih dalam proses
      final hasActiveOrders = orders.any((o) {
        final status = (o['status'] ?? '').toString().toLowerCase();
        return status == 'pending' || status == 'processing';
      });

      // Hanya polling saat ada pesanan aktif. Daftar kosong / error tidak
      // perlu di-poll terus (refresh ulang tersedia lewat pull-to-refresh
      // dan saat app dibuka kembali).
      if (hasActiveOrders && !_isFetching) {
        _loadOrders(silent: true);
      }
    });
  }

  Future<void> _loadOrders({bool silent = false}) async {
    if (_isFetching) return;
    _isFetching = true;

    if (!silent) {
      setState(() {
        isLoading = true;
        errorMessage = null;
      });
    }

    try {
      final result = await ApiService.getOrders();

      _isFetching = false;
      if (!mounted) return;

      setState(() {
        orders = result;
        isLoading = false;
        errorMessage = null;
      });
    } catch (e) {
      _isFetching = false;
      if (!mounted) return;

      if (!silent) {
        setState(() {
          errorMessage = e.toString().replaceFirst('Exception: ', '');
          isLoading = false;
        });
      }
    }
  }

  String formatStatus(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'Menunggu Pembayaran';
      case 'processing':
        return 'Diproses';
      case 'completed':
      case 'complete':
        return 'Selesai';
      case 'cancelled':
      case 'canceled':
        return 'Dibatalkan';
      default:
        return status;
    }
  }

  Color statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
      case 'complete':
        return Colors.green;
      case 'processing':
        return Colors.blue;
      case 'pending':
        return Colors.orange;
      case 'cancelled':
      case 'canceled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pesanan Saya')),

      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (isLoading) {
      return const SkeletonList();
    }

    if (errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,

            children: [
              const Icon(Icons.error_outline, size: 60, color: Colors.red),

              const SizedBox(height: 16),

              Text(errorMessage!, textAlign: TextAlign.center),

              const SizedBox(height: 16),

              ElevatedButton(
                onPressed: _loadOrders,
                child: const Text('Coba Lagi'),
              ),
            ],
          ),
        ),
      );
    }

    if (orders.isEmpty) {
      return RefreshIndicator(
        onRefresh: _loadOrders,

        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),

          children: const [
            SizedBox(height: 180),

            Icon(Icons.receipt_long_outlined, size: 80, color: Colors.grey),

            SizedBox(height: 20),

            Center(
              child: Text(
                'Belum ada pesanan.',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),

            SizedBox(height: 8),

            Center(
              child: Text(
                'Pesanan kamu akan muncul di sini.',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadOrders,

      child: ListView.builder(
        padding: const EdgeInsets.all(16),

        itemCount: orders.length,

        itemBuilder: (context, index) {
          final order = orders[index];

          return _buildOrderCard(order);
        },
      ),
    );
  }

  Widget _buildOrderCard(Map<String, dynamic> order) {
    final String orderNumber = order['order_number'] ?? '-';

    final String status = order['status'] ?? '-';

    final String pickupMethod = order['pickup_method'] ?? '-';

    final String paymentMethod = order['payment_method'] ?? '-';

    final int total = int.tryParse(order['total'].toString()) ?? 0;

    final List<dynamic> items = order['items'] ?? [];

    return Card(
      margin: const EdgeInsets.only(bottom: 16),

      child: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,

          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                Expanded(
                  child: Text(
                    orderNumber,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),

                  decoration: BoxDecoration(
                    color: statusColor(status).withValues(alpha: 0.12),

                    borderRadius: BorderRadius.circular(20),
                  ),

                  child: Text(
                    formatStatus(status),
                    style: TextStyle(
                      color: statusColor(status),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),

            const Divider(height: 24),

            ...items.map((item) {
              final product = item['product'] ?? {};

              final String name = product['name'] ?? 'Produk';

              final int quantity =
                  int.tryParse(item['quantity'].toString()) ?? 0;

              final int subtotal =
                  int.tryParse(item['subtotal'].toString()) ?? 0;

              return Padding(
                padding: const EdgeInsets.only(bottom: 10),

                child: Row(
                  children: [
                    Expanded(child: Text('$name x$quantity')),

                    Text(
                      AppUtils.formatRupiah(subtotal),
                      style: const TextStyle(fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              );
            }),

            const Divider(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                const Text(
                  'Total',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),

                Text(
                  AppUtils.formatRupiah(total),
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            Row(
              children: [
                const Icon(Icons.shopping_bag_outlined, size: 18),

                const SizedBox(width: 8),

                Expanded(child: Text(pickupMethod)),
              ],
            ),

            const SizedBox(height: 6),

            Row(
              children: [
                const Icon(Icons.payment_outlined, size: 18),

                const SizedBox(width: 8),

                Expanded(child: Text(paymentMethod)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}