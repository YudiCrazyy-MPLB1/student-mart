import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'api_service.dart';
import 'app_navigator.dart';
import 'cart_controller.dart';
import 'login_page.dart';

class AuthProvider extends ChangeNotifier {
  AuthProvider() {
    // Satu jalur untuk sesi berakhir: ApiService memanggil ini sekali
    // setiap kali server membalas 401 untuk request yang membawa token.
    ApiService.onUnauthorized = _handleSessionExpired;
  }

  bool _isAuthenticated = false;
  String? _role;

  bool get isAuthenticated => _isAuthenticated;
  String? get role => _role;

  // Cek token dari penyimpanan lokal
  Future<void> checkLoginStatus() async {
    await ApiService.loadToken();
    if (ApiService.authToken != null && ApiService.authToken!.isNotEmpty) {
      _isAuthenticated = true;
      _role = ApiService.userRole;
    } else {
      _isAuthenticated = false;
      _role = null;
    }
    notifyListeners();
  }

  // Panggil ini saat logout sukses
  Future<void> logout() async {
    await ApiService.logout(); // best-effort, tidak pernah melempar error
    _isAuthenticated = false;
    _role = null;
    notifyListeners();
  }

  // Reset state auth (token sudah/akan dihapus).
  void forceLogout() {
    ApiService.clearToken();
    _isAuthenticated = false;
    _role = null;
    notifyListeners();
  }

  /// Dipanggil otomatis oleh ApiService saat sesi berakhir (401).
  void _handleSessionExpired() {
    forceLogout();

    final navigator = navigatorKey.currentState;
    final context = navigatorKey.currentContext;
    if (navigator == null || context == null) return;

    try {
      context.read<CartController>().clearCart();
    } catch (_) {}

    navigator.pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final c = navigatorKey.currentContext;
      if (c == null) return;
      ScaffoldMessenger.maybeOf(c)?.showSnackBar(
        const SnackBar(
          content: Text('Sesi login berakhir. Silakan login kembali.'),
        ),
      );
    });
  }

  @override
  void dispose() {
    if (ApiService.onUnauthorized == _handleSessionExpired) {
      ApiService.onUnauthorized = null;
    }
    super.dispose();
  }
}